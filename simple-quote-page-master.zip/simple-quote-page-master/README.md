# simple-quote-page
A simple quote page
